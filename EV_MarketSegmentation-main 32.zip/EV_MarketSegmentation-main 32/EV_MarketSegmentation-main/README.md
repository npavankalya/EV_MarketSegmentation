# EV_MarketSegmentation
# Description
## This project is basically focused on analysing the EV market segmentation based on the data collected from the varoius datasets from various sources.
# Observaton
## * From the analysis it is seen that the states with high GDP are most likely to have more EVs.
## * Most of the vehicles sold are the passenger vehicle rather than commercial vehicles.
## * The EV sales depend mostly on number of charging stations.
## * The market is more open towards the compact cars and bit towards larger ones and mid budget.
